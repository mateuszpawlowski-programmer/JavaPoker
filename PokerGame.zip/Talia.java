/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author M
 */
public class Talia {
    
    public ArrayList<Card> talia=new ArrayList<Card>();
    
    Talia()
    {
        talia.add(new Card(Kolor.Spade,Wartosc._A));
        talia.add(new Card(Kolor.Spade,Wartosc._K));
        talia.add(new Card(Kolor.Spade,Wartosc._Q));
        talia.add(new Card(Kolor.Spade,Wartosc._J));
        talia.add(new Card(Kolor.Spade,Wartosc._10));
        talia.add(new Card(Kolor.Spade,Wartosc._9));
        //talia.add(new Card(Kolor.Spade,Wartosc._8));
        //talia.add(new Card(Kolor.Spade,Wartosc._7));
        //talia.add(new Card(Kolor.Spade,Wartosc._6));
        //talia.add(new Card(Kolor.Spade,Wartosc._5));
        //talia.add(new Card(Kolor.Spade,Wartosc._4));
        //talia.add(new Card(Kolor.Spade,Wartosc._3));
        //talia.add(new Card(Kolor.Spade,Wartosc._2));
        
        
        
        talia.add(new Card(Kolor.Diamond,Wartosc._A));
        talia.add(new Card(Kolor.Diamond,Wartosc._K));
        talia.add(new Card(Kolor.Diamond,Wartosc._Q));
        talia.add(new Card(Kolor.Diamond,Wartosc._J));
        talia.add(new Card(Kolor.Diamond,Wartosc._10));
        talia.add(new Card(Kolor.Diamond,Wartosc._9));
        //talia.add(new Card(Kolor.Diamond,Wartosc._8));
        //talia.add(new Card(Kolor.Diamond,Wartosc._7));
        //talia.add(new Card(Kolor.Diamond,Wartosc._6));
        //talia.add(new Card(Kolor.Diamond,Wartosc._5));
        //talia.add(new Card(Kolor.Diamond,Wartosc._4));
        //talia.add(new Card(Kolor.Diamond,Wartosc._3));
        //talia.add(new Card(Kolor.Diamond,Wartosc._2));
        
        
        
        talia.add(new Card(Kolor.Heart,Wartosc._A));
        talia.add(new Card(Kolor.Heart,Wartosc._K));
        talia.add(new Card(Kolor.Heart,Wartosc._Q));
        talia.add(new Card(Kolor.Heart,Wartosc._J));
        talia.add(new Card(Kolor.Heart,Wartosc._10));
        talia.add(new Card(Kolor.Heart,Wartosc._9));
        //talia.add(new Card(Kolor.Heart,Wartosc._8));
        //talia.add(new Card(Kolor.Heart,Wartosc._7));
        //talia.add(new Card(Kolor.Heart,Wartosc._6));
        //talia.add(new Card(Kolor.Heart,Wartosc._5));
        //talia.add(new Card(Kolor.Heart,Wartosc._4));
        //talia.add(new Card(Kolor.Heart,Wartosc._3));
        //talia.add(new Card(Kolor.Heart,Wartosc._2));
        
        
        talia.add(new Card(Kolor.Club,Wartosc._A));
        talia.add(new Card(Kolor.Club,Wartosc._K));
        talia.add(new Card(Kolor.Club,Wartosc._Q));
        talia.add(new Card(Kolor.Club,Wartosc._J));
        talia.add(new Card(Kolor.Club,Wartosc._10));
        talia.add(new Card(Kolor.Club,Wartosc._9));
        //talia.add(new Card(Kolor.Club,Wartosc._8));
        //talia.add(new Card(Kolor.Club,Wartosc._7));
        //talia.add(new Card(Kolor.Club,Wartosc._6));
        //talia.add(new Card(Kolor.Club,Wartosc._5));
        //talia.add(new Card(Kolor.Club,Wartosc._4));
        //talia.add(new Card(Kolor.Club,Wartosc._3));
        //talia.add(new Card(Kolor.Club,Wartosc._2));
    }
    
    
    public void show()
    {
        System.out.println();
    
        int i=0;
        for(Card c:this.talia)
        {
        if(i==13){i=0;System.out.println();}
        c.getCard();
        i++;
        }
    }
    
    public Card losuj_karte()
    {
        Random random=new Random();
        random.setSeed(System.currentTimeMillis());
        
        int los=random.nextInt(talia.size());
        //System.out.print("Wylosowalem: "+los+" ");
        int i=0;
        Card wylosowana=null;
        
        for(Card c:this.talia)
        {
            if(i==los)
            {
                wylosowana=c;
                talia.remove(i);
                break;
            }
            i++;
        }
        
        //wylosowana.getCard();
        return wylosowana;
    }
    
    public void dodaj_karte(Card c)
    {
        this.talia.add(c);
    }
}
