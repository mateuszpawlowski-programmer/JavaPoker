/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

/**
 *
 * @author M
 */
public enum Wartosc {
  
    _0("0"){public String toString(){return this.getWartosc();}},
    
    _2("2"){public String toString(){return this.getWartosc();}},
    _3("3"){public String toString(){return this.getWartosc();}},
    _4("4"){public String toString(){return this.getWartosc();}},
    _5("5"){public String toString(){return this.getWartosc();}},
    _6("6"){public String toString(){return this.getWartosc();}},
    _7("7"){public String toString(){return this.getWartosc();}},
    _8("8"){public String toString(){return this.getWartosc();}},
    _9("9"){public String toString(){return this.getWartosc();}},
    _10("10"){public String toString(){return this.getWartosc();}},
    
    _J("11"){public String toString(){return this.getWartosc();}},
    _Q("12"){public String toString(){return this.getWartosc();}},
    _K("13"){public String toString(){return this.getWartosc();}},
    _A("14"){public String toString(){return this.getWartosc();}};

    
    Wartosc(String s)
    {   
    wartosc=s;
    }

    public String getWartosc(){return wartosc;}
    
    private final String wartosc;
}
