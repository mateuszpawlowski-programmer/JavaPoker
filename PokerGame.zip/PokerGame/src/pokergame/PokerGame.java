/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;


/**
 *
 * @author M
 */



public class PokerGame {

     public static Talia t1=new Talia();
     
     public static Gracz gracz_1=new Gracz("1",t1);
     
     public static Gracz gracz_2=new Gracz("2",t1);
        
     public static int round=0;
     public static int game_money=0;
     
     public static void losuj_5_kart_dla_obu_graczy()
     {
      //losuj po 5 kart dla obu graczy
        for(int i=0;i<5;i++){
        gracz_1.dodaj_karte(t1.losuj_karte());
        }
        
        for(int i=0;i<5;i++){
        gracz_2.dodaj_karte(t1.losuj_karte());
        }
     }
     
     public static void ruch_gracza_1()
     {
        try
        {
                
                
                //ArrayList<Integer> do_wymiany=podaj_karty_do_wymiany();
                ArrayList<Integer> do_wymiany=przyciski_lista;
           
           
            
                
                //ArrayList<Integer> do_wymiany=PokerGame.przyciski_lista;
            
            
                if(do_wymiany!=null){
                        System.out.println("Wymieniam: "+do_wymiany);

                        gracz_1.wymien(do_wymiany);
                        //gracz_1.show();

                                for(int i=0;i<do_wymiany.size();i++){
                                    //gracz_1.dodaj_karte(t1.losuj_karte());
                                }
                                //gracz_1.show();
                                //t1.show();
                }
        }
        catch(Exception exc){}
        
        gracz_1.show();
        
     }
     
     public static void ruch_gracza_2()
     {
        try
        {
                ArrayList<Integer> do_wymiany=new ArrayList<Integer>();
                do_wymiany=gracz_2.jedynki_do_wymiany;
                
                //do_wymiany.add(0);
                //do_wymiany.add(1);


                if(do_wymiany!=null){
                        //System.out.println("Wymieniam: "+do_wymiany);

                        gracz_2.wymien(do_wymiany);
                        //gracz_1.show();

                                for(int i=0;i<do_wymiany.size();i++){
                                //gracz_2.dodaj_karte(t1.losuj_karte());
                                }
                                gracz_2.show();
                                //t1.show();
                }
        }
        catch(Exception exc){}
     }
     
    public static boolean p1=false;
    public static boolean p2=false;
    public static boolean p3=false;
    public static boolean p4=false;
    public static boolean p5=false;
        
    public static void przycisk_1(){if(p1==true) p1=false; else p1=true;}
    public static void przycisk_2(){if(p2==true) p2=false; else p2=true;}
    public static void przycisk_3(){if(p3==true) p3=false; else p3=true;}
    public static void przycisk_4(){if(p4==true) p4=false; else p4=true;}
    public static void przycisk_5(){if(p5==true) p5=false; else p5=true;}
    
    public static JToggleButton b1=new JToggleButton();
    public static JToggleButton b2=new JToggleButton();
    public static JToggleButton b3=new JToggleButton();
    public static JToggleButton b4=new JToggleButton();
    public static JToggleButton b5=new JToggleButton();
    
    public static JToggleButton b11=new JToggleButton();
    public static JToggleButton b12=new JToggleButton();
    public static JToggleButton b13=new JToggleButton();
    public static JToggleButton b14=new JToggleButton();
    public static JToggleButton b15=new JToggleButton();
    
    public static JLabel napis_gracz_1=new JLabel("Player 1");
    public static JLabel napis_gracz_2=new JLabel("Computer");
    
     public static JLabel gracz_1_money=new JLabel("<html>Player money:<br>"+gracz_1.money+"$</html>");
     public static JLabel gracz_2_money=new JLabel("<html>Computer money:<br>"+gracz_2.money+"$</html>");
        
     public static JLabel game_money_label=new JLabel("<html><center>Game money:<br>"+game_money+"$</center></html>");
    
    public static ArrayList<Integer> przyciski_lista=new ArrayList<Integer>();
    
    public static void przycisk_bet()
    {
            if(gracz_1.money>=100)
            {
                gracz_1.money=gracz_1.money-100;
                game_money=game_money+100;
            }
            
            gracz_1_money.setText("<html>Player money:<br>"+gracz_1.money+"$</html>");
            game_money_label.setText("<html><center>Game money:<br>"+game_money+"$</center></html>");
            
    }
    
    public static void computer_bet()
    {
            if(gracz_2.money>=100)
            {
                gracz_2.money=gracz_2.money-100;
                game_money=game_money+100;
            }
            
            gracz_2_money.setText("<html>Computer money:<br>"+gracz_2.money+"$</html>");
            game_money_label.setText("<html><center>Game money:<br>"+game_money+"$</center></html>");
    }
    
    public static void przycisk_6()
    {
    
    round++;
    
    Random computer_bet_prob=new Random();
    computer_bet_prob.setSeed(System.currentTimeMillis());
    
    int cbp=computer_bet_prob.nextInt(2)+1;
    if(cbp==1){computer_bet();}
    if(cbp==2){computer_bet();computer_bet();}
    if(cbp==3){computer_bet();computer_bet();computer_bet();}
    
    gracz_1_money.setText("<html>Player money:<br>"+gracz_1.money+"$</html>");
    gracz_2_money.setText("<html>Computer money:<br>"+gracz_2.money+"$</html>");
    game_money_label.setText("<html><center>Game money:<br>"+game_money+"$</center></html>");
    
    
    
    przyciski_lista=new ArrayList<Integer>();
    
    if(p1==true) przyciski_lista.add(0);
    if(p2==true) przyciski_lista.add(1);
    if(p3==true) przyciski_lista.add(2);
    if(p4==true) przyciski_lista.add(3);
    if(p5==true) przyciski_lista.add(4);
    
    System.out.println(przyciski_lista.toString());
    
        PokerGame.ruch_gracza_1();
        gracz_1.sprawdz_rozdanie();
        napis_gracz_1.setText(gracz_1.pobierz_rozdanie());
        
        b1.setText(gracz_1.karty.get(0).toString());
        b2.setText(gracz_1.karty.get(1).toString());
        b3.setText(gracz_1.karty.get(2).toString());
        b4.setText(gracz_1.karty.get(3).toString());
        b5.setText(gracz_1.karty.get(4).toString());
        
        if(b1.isSelected()){b1.doClick();}
        if(b2.isSelected()){b2.doClick();}
        if(b3.isSelected()){b3.doClick();}
        if(b4.isSelected()){b4.doClick();}
        if(b5.isSelected()){b5.doClick();}
        
        
        PokerGame.ruch_gracza_2();
        gracz_2.sprawdz_rozdanie();
        napis_gracz_2.setText(gracz_2.pobierz_rozdanie());
        
        b11.setText(gracz_2.karty.get(0).toString());
        b12.setText(gracz_2.karty.get(1).toString());
        b13.setText(gracz_2.karty.get(2).toString());
        b14.setText(gracz_2.karty.get(3).toString());
        b15.setText(gracz_2.karty.get(4).toString());
        
       
       b1.setForeground(Color.black);b2.setForeground(Color.black);b3.setForeground(Color.black);b4.setForeground(Color.black);b5.setForeground(Color.black);
       if(gracz_1.karty.get(0).kolor.equals(Kolor.Heart)||gracz_1.karty.get(0).kolor.equals(Kolor.Diamond)){b1.setForeground(Color.red);}
       if(gracz_1.karty.get(1).kolor.equals(Kolor.Heart)||gracz_1.karty.get(1).kolor.equals(Kolor.Diamond)){b2.setForeground(Color.red);}
       if(gracz_1.karty.get(2).kolor.equals(Kolor.Heart)||gracz_1.karty.get(2).kolor.equals(Kolor.Diamond)){b3.setForeground(Color.red);}
       if(gracz_1.karty.get(3).kolor.equals(Kolor.Heart)||gracz_1.karty.get(3).kolor.equals(Kolor.Diamond)){b4.setForeground(Color.red);}
       if(gracz_1.karty.get(4).kolor.equals(Kolor.Heart)||gracz_1.karty.get(4).kolor.equals(Kolor.Diamond)){b5.setForeground(Color.red);}
        
       
       b11.setForeground(Color.black);b12.setForeground(Color.black);b13.setForeground(Color.black);b14.setForeground(Color.black);b15.setForeground(Color.black);
       if(gracz_2.karty.get(0).kolor.equals(Kolor.Heart)||gracz_2.karty.get(0).kolor.equals(Kolor.Diamond)){b11.setForeground(Color.red);}
       if(gracz_2.karty.get(1).kolor.equals(Kolor.Heart)||gracz_2.karty.get(1).kolor.equals(Kolor.Diamond)){b12.setForeground(Color.red);}
       if(gracz_2.karty.get(2).kolor.equals(Kolor.Heart)||gracz_2.karty.get(2).kolor.equals(Kolor.Diamond)){b13.setForeground(Color.red);}
       if(gracz_2.karty.get(3).kolor.equals(Kolor.Heart)||gracz_2.karty.get(3).kolor.equals(Kolor.Diamond)){b14.setForeground(Color.red);}
       if(gracz_2.karty.get(4).kolor.equals(Kolor.Heart)||gracz_2.karty.get(4).kolor.equals(Kolor.Diamond)){b15.setForeground(Color.red);}
       
       if(round==4)
       {
           
           //sprawdz kto wygral i rozdaj pieniadze
           int player_hand_power=0;
           int computer_hand_power=0;
           
           
           if(gracz_1.rozdanie.indexOf("One")!=-1){System.out.println("One Pair");player_hand_power=1;};
           if(gracz_1.rozdanie.indexOf("Two")!=-1){System.out.println("Two Pair");player_hand_power=2;};
           if(gracz_1.rozdanie.indexOf("Three")!=-1){System.out.println("Three");player_hand_power=3;};
           if(gracz_1.rozdanie.indexOf("Straight")!=-1){System.out.println("Straight");player_hand_power=4;};
           if(gracz_1.rozdanie.indexOf("Flush")!=-1){System.out.println("Flush");player_hand_power=5;};
           if(gracz_1.rozdanie.indexOf("Full")!=-1){System.out.println("Full");player_hand_power=6;};
           if(gracz_1.rozdanie.indexOf("Four")!=-1){System.out.println("Four");player_hand_power=7;};
           if(gracz_1.rozdanie.indexOf("Poker")!=-1){System.out.println("Poker");player_hand_power=8;};
           
           
           if(gracz_2.rozdanie.indexOf("One")!=-1){System.out.println("One Pair");computer_hand_power=1;};
           if(gracz_2.rozdanie.indexOf("Two")!=-1){System.out.println("Two Pair");computer_hand_power=2;};
           if(gracz_2.rozdanie.indexOf("Three")!=-1){System.out.println("Three");computer_hand_power=3;};
           if(gracz_2.rozdanie.indexOf("Straight")!=-1){System.out.println("Straight");computer_hand_power=4;};
           if(gracz_2.rozdanie.indexOf("Flush")!=-1){System.out.println("Flush");computer_hand_power=5;};
           if(gracz_2.rozdanie.indexOf("Full")!=-1){System.out.println("Full");computer_hand_power=6;};
           if(gracz_2.rozdanie.indexOf("Four")!=-1){System.out.println("Four");computer_hand_power=7;};
           if(gracz_2.rozdanie.indexOf("Poker")!=-1){System.out.println("Poker");computer_hand_power=8;};
           
           
           int p1m=gracz_1.money;
           int p2m=gracz_2.money;
           
           if(player_hand_power>computer_hand_power)
           {
           p1m=gracz_1.money=gracz_1.money+game_money;
           game_money=0;
           }
           
           if(player_hand_power<computer_hand_power)
           {
           p2m=gracz_2.money=gracz_2.money+game_money;
           game_money=0;
           }
           
           gracz_1_money.setText("<html>Player money:<br>"+gracz_1.money+"$</html>");
           gracz_2_money.setText("<html>Computer money:<br>"+gracz_2.money+"$</html>");
           game_money_label.setText("<html><center>Game money:<br>"+game_money+"$</center></html>");
           
           
           
           
            
           //
           String s1=""+gracz_1.pobierz_rozdanie();
           String s2=""+gracz_2.pobierz_rozdanie();
           
           String s3=s1.replaceAll("<.*?>", " ");
           String s4=s2.replaceAll("<.*?>", " ");
           
           System.out.println(s4);
           JOptionPane.showMessageDialog(null, "<html>"+s3+"<br><br>"+s4+"<html>", "New game", JOptionPane.PLAIN_MESSAGE);
           
           
                   
           round=0;
           
           t1=new Talia();
           gracz_1=new Gracz("1",t1);gracz_1.money=p1m;
           gracz_2=new Gracz("2",t1);gracz_2.money=p2m;
           PokerGame.losuj_5_kart_dla_obu_graczy();
            
           gracz_1.sprawdz_rozdanie();
           napis_gracz_1.setText(gracz_1.pobierz_rozdanie());   
           gracz_2.sprawdz_rozdanie();
           napis_gracz_2.setText(gracz_2.pobierz_rozdanie());   
        
           
           cbp=computer_bet_prob.nextInt(2)+1;
           if(cbp==1){computer_bet();}
           if(cbp==2){computer_bet();computer_bet();}
           if(cbp==3){computer_bet();computer_bet();computer_bet();}

           gracz_1_money.setText("<html>Player money:<br>"+gracz_1.money+"$</html>");
           gracz_2_money.setText("<html>Computer money:<br>"+gracz_2.money+"$</html>");
           game_money_label.setText("<html><center>Game money:<br>"+game_money+"$</center></html>");
           
           
           
           
        b1.setText(gracz_1.karty.get(0).toString());
        b2.setText(gracz_1.karty.get(1).toString());
        b3.setText(gracz_1.karty.get(2).toString());
        b4.setText(gracz_1.karty.get(3).toString());
        b5.setText(gracz_1.karty.get(4).toString());
        
        b11.setText(gracz_2.karty.get(0).toString());
        b12.setText(gracz_2.karty.get(1).toString());
        b13.setText(gracz_2.karty.get(2).toString());
        b14.setText(gracz_2.karty.get(3).toString());
        b15.setText(gracz_2.karty.get(4).toString());
       
       
        b1.setForeground(Color.black);b2.setForeground(Color.black);b3.setForeground(Color.black);b4.setForeground(Color.black);b5.setForeground(Color.black);
        if(gracz_1.karty.get(0).kolor.equals(Kolor.Heart)||gracz_1.karty.get(0).kolor.equals(Kolor.Diamond)){b1.setForeground(Color.red);}
        if(gracz_1.karty.get(1).kolor.equals(Kolor.Heart)||gracz_1.karty.get(1).kolor.equals(Kolor.Diamond)){b2.setForeground(Color.red);}
        if(gracz_1.karty.get(2).kolor.equals(Kolor.Heart)||gracz_1.karty.get(2).kolor.equals(Kolor.Diamond)){b3.setForeground(Color.red);}
        if(gracz_1.karty.get(3).kolor.equals(Kolor.Heart)||gracz_1.karty.get(3).kolor.equals(Kolor.Diamond)){b4.setForeground(Color.red);}
        if(gracz_1.karty.get(4).kolor.equals(Kolor.Heart)||gracz_1.karty.get(4).kolor.equals(Kolor.Diamond)){b5.setForeground(Color.red);}


        b11.setForeground(Color.black);b12.setForeground(Color.black);b13.setForeground(Color.black);b14.setForeground(Color.black);b15.setForeground(Color.black);
        if(gracz_2.karty.get(0).kolor.equals(Kolor.Heart)||gracz_2.karty.get(0).kolor.equals(Kolor.Diamond)){b11.setForeground(Color.red);}
        if(gracz_2.karty.get(1).kolor.equals(Kolor.Heart)||gracz_2.karty.get(1).kolor.equals(Kolor.Diamond)){b12.setForeground(Color.red);}
        if(gracz_2.karty.get(2).kolor.equals(Kolor.Heart)||gracz_2.karty.get(2).kolor.equals(Kolor.Diamond)){b13.setForeground(Color.red);}
        if(gracz_2.karty.get(3).kolor.equals(Kolor.Heart)||gracz_2.karty.get(3).kolor.equals(Kolor.Diamond)){b14.setForeground(Color.red);}
        if(gracz_2.karty.get(4).kolor.equals(Kolor.Heart)||gracz_2.karty.get(4).kolor.equals(Kolor.Diamond)){b15.setForeground(Color.red);}
       }
    }
    
    public static JFrame frame=new JFrame("PokerGame 2023. Mateusz Pawlowski.");
    public static JPanel panel=new JPanel();
    public static JPanel panel2=new JPanel();
    public static JPanel panel3=new JPanel();
    public static JPanel panel4=new JPanel();
    public static JPanel panel5=new JPanel();
    public static JPanel panel6=new JPanel();
    
    public static void main(String[] args) {
         
        //t1.show();
        //JFrame frame=new JFrame("PokerGame");
        
        //JPanel panel=new JPanel();
        //JPanel panel2=new JPanel();
        
        frame.setLayout(new GridLayout(4,0));
        panel5.setLayout(new GridLayout(0,6));
        panel.setLayout(new GridLayout(0,6));
        
        frame.getContentPane().add(panel);
        frame.getContentPane().add(panel2);
        frame.getContentPane().add(panel6);
        frame.getContentPane().add(panel5);
        
        
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setPreferredSize(new Dimension(500,350));
        
        
        
        
        napis_gracz_1.setFont(new Font("System",Font.BOLD,12));
        napis_gracz_2.setFont(new Font("System",Font.BOLD,12));
        
        panel.add(napis_gracz_1);
        panel.add(b1);b1.setBackground(Color.WHITE);
        panel.add(b2);b2.setBackground(Color.WHITE);
        panel.add(b3);b3.setBackground(Color.WHITE);
        panel.add(b4);b4.setBackground(Color.WHITE);
        panel.add(b5);b5.setBackground(Color.WHITE);
        
        panel5.add(napis_gracz_2);
        panel5.add(b11);b11.setBackground(Color.WHITE);
        panel5.add(b12);b12.setBackground(Color.WHITE);
        panel5.add(b13);b13.setBackground(Color.WHITE);
        panel5.add(b14);b14.setBackground(Color.WHITE);
        panel5.add(b15);b15.setBackground(Color.WHITE);
        
        ActionListener action_1=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_1();
            }
        };
        
        ActionListener action_2=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_2();
            }
        };
        
        ActionListener action_3=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_3();
            }
        };
        
        ActionListener action_4=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_4();
            }
        };
        
        ActionListener action_5=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_5();
            }
        };
        
        ActionListener action_6=new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_6();
            }
        };
        
        ActionListener action_bet=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                przycisk_bet();
            }
        };
        
        b1.addActionListener(action_1);
        b2.addActionListener(action_2);
        b3.addActionListener(action_3);
        b4.addActionListener(action_4);
        b5.addActionListener(action_5);
        
        
        Color col2=new Color(0,140,0);
        Color col3=new Color(0,140,0);
        
        panel.setBackground(new Color(255,255,255));
        panel5.setBackground(new Color(255,255,255));
        panel6.setBackground(new Color(0,140,0));
        
        JButton b6=new JButton("Change cards");
        b6.setBackground(Color.WHITE);
        
        JButton b7=new JButton("Bet");
        b7.setBackground(Color.WHITE);
        
        //panel2.setAlignmentY(SwingConstants.CENTER);
        
        gracz_1_money=new JLabel("<html>Player money:<br>"+gracz_1.money+"$</html>");
        gracz_2_money=new JLabel("<html>Computer money:<br>"+gracz_2.money+"$</html>");
        
        game_money_label=new JLabel("<html><center>Game money:<br>"+game_money+"$</center></html>");
        
        JLabel empty_label=new JLabel("       ");
        JLabel empty_label_2=new JLabel("       ");
        
        JLabel bet_info=new JLabel("Bet Info");
        
        panel2.add(gracz_1_money);
        panel2.add(empty_label);
        
        panel2.add(b6);
        panel2.add(b7);
        
        
        panel2.add(empty_label_2);
        panel2.add(gracz_2_money);
        
        panel6.add(game_money_label);
        
        //panel2.add(bet_info);
        
        Color col=new Color(0,140,0);
        panel2.setBackground(col);
        
        b6.addActionListener(action_6);
        b7.addActionListener(action_bet);
        
        
        
       
        
        
        PokerGame.losuj_5_kart_dla_obu_graczy();
        
        
        
        Random computer_bet_prob=new Random();
        computer_bet_prob.setSeed(System.currentTimeMillis());
    
        int cbp=computer_bet_prob.nextInt(2)+1;
        if(cbp==1){computer_bet();}
        if(cbp==2){computer_bet();computer_bet();}
        if(cbp==3){computer_bet();computer_bet();computer_bet();}
        /*
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._K));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._Q));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._J));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._10));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._9));
        
        
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Diamond,Wartosc._0));
        */
        
        b1.setText(gracz_1.karty.get(0).toString());
        b2.setText(gracz_1.karty.get(1).toString());
        b3.setText(gracz_1.karty.get(2).toString());
        b4.setText(gracz_1.karty.get(3).toString());
        b5.setText(gracz_1.karty.get(4).toString());
        
        b11.setText(gracz_2.karty.get(0).toString());
        b12.setText(gracz_2.karty.get(1).toString());
        b13.setText(gracz_2.karty.get(2).toString());
        b14.setText(gracz_2.karty.get(3).toString());
        b15.setText(gracz_2.karty.get(4).toString());
       
       
       b1.setForeground(Color.black);b2.setForeground(Color.black);b3.setForeground(Color.black);b4.setForeground(Color.black);b5.setForeground(Color.black);
       if(gracz_1.karty.get(0).kolor.equals(Kolor.Heart)||gracz_1.karty.get(0).kolor.equals(Kolor.Diamond)){b1.setForeground(Color.red);}
       if(gracz_1.karty.get(1).kolor.equals(Kolor.Heart)||gracz_1.karty.get(1).kolor.equals(Kolor.Diamond)){b2.setForeground(Color.red);}
       if(gracz_1.karty.get(2).kolor.equals(Kolor.Heart)||gracz_1.karty.get(2).kolor.equals(Kolor.Diamond)){b3.setForeground(Color.red);}
       if(gracz_1.karty.get(3).kolor.equals(Kolor.Heart)||gracz_1.karty.get(3).kolor.equals(Kolor.Diamond)){b4.setForeground(Color.red);}
       if(gracz_1.karty.get(4).kolor.equals(Kolor.Heart)||gracz_1.karty.get(4).kolor.equals(Kolor.Diamond)){b5.setForeground(Color.red);}
        
       
       b11.setForeground(Color.black);b12.setForeground(Color.black);b13.setForeground(Color.black);b14.setForeground(Color.black);b15.setForeground(Color.black);
       if(gracz_2.karty.get(0).kolor.equals(Kolor.Heart)||gracz_2.karty.get(0).kolor.equals(Kolor.Diamond)){b11.setForeground(Color.red);}
       if(gracz_2.karty.get(1).kolor.equals(Kolor.Heart)||gracz_2.karty.get(1).kolor.equals(Kolor.Diamond)){b12.setForeground(Color.red);}
       if(gracz_2.karty.get(2).kolor.equals(Kolor.Heart)||gracz_2.karty.get(2).kolor.equals(Kolor.Diamond)){b13.setForeground(Color.red);}
       if(gracz_2.karty.get(3).kolor.equals(Kolor.Heart)||gracz_2.karty.get(3).kolor.equals(Kolor.Diamond)){b14.setForeground(Color.red);}
       if(gracz_2.karty.get(4).kolor.equals(Kolor.Heart)||gracz_2.karty.get(4).kolor.equals(Kolor.Diamond)){b15.setForeground(Color.red);}
       
        frame.setVisible(true);
        frame.pack();
        
        /*
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._3));
        gracz_1.dodaj_karte(new Card(Kolor.Spade,Wartosc._3));
        gracz_1.dodaj_karte(new Card(Kolor.Diamond,Wartosc._3));
        
        
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Spade,Wartosc._A));
        gracz_2.dodaj_karte(new Card(Kolor.Diamond,Wartosc._0));
        */
        
        System.out.println("");
        System.out.println("");
        
        
        gracz_1.show();
        gracz_1.sprawdz_rozdanie();
        napis_gracz_1.setText(gracz_1.pobierz_rozdanie());
        
        gracz_2.show();
        gracz_2.sprawdz_rozdanie();
        napis_gracz_2.setText(gracz_2.pobierz_rozdanie());
        
        /*
        PokerGame.ruch_gracza_1();
        gracz_1.sprawdz_rozdanie();
        PokerGame.ruch_gracza_2();
        gracz_2.sprawdz_rozdanie();
         
        PokerGame.ruch_gracza_1();
        gracz_1.sprawdz_rozdanie();
        PokerGame.ruch_gracza_2();
        gracz_2.sprawdz_rozdanie();
        
        PokerGame.ruch_gracza_1();
        gracz_1.sprawdz_rozdanie();
        PokerGame.ruch_gracza_2();
        gracz_2.sprawdz_rozdanie();
        */
    }
    
    
    public static ArrayList<Integer> podaj_karty_do_wymiany()
    {
        ArrayList<Integer> wymien=new ArrayList<Integer>();
        
        String odp=JOptionPane.showInputDialog(null, "Podaj karty do wymiany (0 - 4) :");
        StringTokenizer st=new StringTokenizer(odp);
        //System.out.print("\n Wymieniam");
        while(st.hasMoreTokens()){
            String s=st.nextToken(" ");
            //System.out.print(" "+s);
            wymien.add(Integer.parseInt(s));
        }
        return wymien;
    }
}
