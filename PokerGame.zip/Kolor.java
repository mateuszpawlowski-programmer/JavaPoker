/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

/**
 *
 * @author M
 */
public enum Kolor
{


    
    EmptyCard(" "){
                public String toString(){return ""+this.getSymbol();}
    },
    Spade("♠"){
                public String toString(){return ""+this.getSymbol();}
    },
    
    Diamond("♦"){
                public String toString(){return ""+this.getSymbol();}
    },
    
    Heart("♥"){
                public String toString(){return ""+this.getSymbol();}
    },
    
    Club("♣"){
                public String toString(){return ""+this.getSymbol();}
    };
    
    
    Kolor(String c)
    {
    s=c;
    }


    public String getSymbol(){return s;}
    public final String s;
    
}