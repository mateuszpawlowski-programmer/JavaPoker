/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

/**
 *
 * @author M
 */
public class Gracz {
    
    Talia t;
    
    ArrayList<Card> karty=new ArrayList<Card>();
    
    ArrayList<Card> do_wymiany=new ArrayList<Card>();
    
    String name;
    
    String rozdanie="";
    
    boolean []straight =new boolean[]{false,false,false,false,false,false};
    
    //dla gracza 2 wymien tylko pojedyncze
    ArrayList<Integer> jedynki_do_wymiany=new ArrayList<Integer>();
    
    public Gracz(String n,Talia t)
    {
    name=n;
    this.t=t;
    }
    
    public void dodaj_karte(Card c)
    {
    karty.add(c);
    }
    
    public void show()
    {
        System.out.print("\n Gracz "+name+":");
        String napis=" ";
        
        for(Card c:karty)
        {
            napis=napis+c;
        }
        System.out.println(napis);
    }
    
    public void show_do_wymiany()
    {
        System.out.print("\n");
        for(Card c:do_wymiany)
        {
            c.getCard();
        }
    }
    
    public void znajdz_i_wymien_karte(Card find)
    {
       ListIterator<Card> it=karty.listIterator();
       
       Card szukana_karta=null;
       
       while(it.hasNext())
       {
            Card c=it.next();
            if(c.equals(find))
            {
            szukana_karta=c;
            it.remove();
            
            it.add(t.losuj_karte());
            
            }
       }
       
       this.t.dodaj_karte(szukana_karta);
            
       
    }
    
    public void wymien(ArrayList<Integer> dw)
    {
        
        do_wymiany=new ArrayList<Card>();
        
        for(int ktora:dw){
            for(int i=0;i<karty.size();i++)
            {
                if(i==ktora){
                    //System.out.println(ktora);
                    do_wymiany.add(karty.get(i));
                }
            }
        }
        //show_do_wymiany();
        
        for(Card c:do_wymiany)
        {
            znajdz_i_wymien_karte(c);
        }
    }
    
    public String pobierz_rozdanie()
    {
    return rozdanie;
    }
    
    public void sprawdz_rozdanie()
    {
    
    ArrayList<Integer> ilosc_wystapien=new ArrayList<Integer>();
    
    ArrayList<Integer> ilosc_wystapien_kolor=new ArrayList<Integer>();
    
    //dla gracza 2 wymien tylko pojedyncze
    ArrayList<Integer> ilosc_wystapien_pojedyncze=new ArrayList<Integer>();
    
        //sprawdz kolor
        for(int i=0;i<5;i++)
        {


            Card c=karty.get(i);
            int ilosc=0;

            for(int j=0;j<5;j++)
            {

                Card c2=karty.get(j);
                if(c.kolor.equals(c2.kolor))
                {
                ilosc++;
                }

            }
            ilosc_wystapien_kolor.add(ilosc);

        }
        
        rozdanie="";
        
        if(ilosc_wystapien_kolor.get(0)==5)
        {
            String who="";
            if(this.name.equals("1")) who="Player 1:<br><br>";
            if(this.name.equals("2")) who="Computer:<br><br>";
        
            rozdanie="<html>"+who+" Flush</html>";
            
            
            
            
            System.out.println(" Flush");
            //Jezeli kolor to sprawdz czy rowniez straigth = poker
            //sprawdz czy straigth
                    this.straight=new boolean[] {false,false,false,false,false,false};
                    
                    for(int i=0;i<5;i++)
                    {
                    Card c=karty.get(i);
                    if(c.wartosc.equals(Wartosc._9)){this.straight[0]=true;}
                    else if(c.wartosc.equals(Wartosc._10)){this.straight[1]=true;}
                    else if(c.wartosc.equals(Wartosc._J)){this.straight[2]=true;}
                    else if(c.wartosc.equals(Wartosc._Q)){this.straight[3]=true;}
                    else if(c.wartosc.equals(Wartosc._K)){this.straight[4]=true;}
                    else if(c.wartosc.equals(Wartosc._A)){this.straight[5]=true;}
                    }

                    for(int i=0;i<6;i++)
                    {
                    System.out.print(" "+this.straight[i]);
                    }
                    //
                    if(straight[0]==true&&straight[1]==true&&straight[2]==true&&straight[3]==true&&straight[4]==true)
                    {
                        rozdanie="<html>"+who+" Straight</html>";
                        if(ilosc_wystapien_kolor.get(0)==5)
                        {
                        rozdanie="<html>"+who+" Poker</html>";
                        }
                    };
                    
                    if(straight[1]==true&&straight[2]==true&&straight[3]==true&&straight[4]==true&&straight[5]==true)
                    {
                        rozdanie="<html>"+who+" Straight</html>";
                        if(ilosc_wystapien_kolor.get(0)==5)
                        {
                        rozdanie="<html>"+who+" Poker</html>";
                        }
                    };
            //
            return;
        }
        
        //sprawdz rozdanie
        for(int i=0;i<5;i++)
        {


            Card c=karty.get(i);
            int ilosc=0;

            for(int j=0;j<5;j++)
            {

                Card c2=karty.get(j);
                if(c.wartosc.equals(c2.wartosc))
                {
                ilosc++;
                }

            }
            ilosc_wystapien.add(ilosc);

        }
        //System.out.println(ilosc_wystapien.toString());
        
        
        int dwa=0;
        int trzy=0;
        int cztery=0;
        
        for(int i=0;i<5;i++)
        {
        if(ilosc_wystapien.get(i)==2){dwa++;}
        if(ilosc_wystapien.get(i)==3){trzy++;}
        if(ilosc_wystapien.get(i)==4){cztery++;}
        }
        
        //System.out.print("   2:"+dwa);
        //System.out.print("   3:"+trzy);
        //System.out.print("   4:"+cztery);
        String who="";
        if(this.name.equals("1")) who="Player 1 :<br><br>";
        if(this.name.equals("2")) who="Computer :<br><br>";
        
        rozdanie="<html>"+who+"</html>";
        
        if(dwa==2&&trzy==0){System.out.println(" One pair"); rozdanie="<html>"+who+" One pair</html>";}
        if(dwa==4){System.out.println(" Two pair"); rozdanie="<html>"+who+" Two pair</html>";}
        if(dwa==0&&trzy==3){System.out.println(" Three of a kind"); rozdanie="<html>"+who+" Three <br> of a kind</html>";}
        if(dwa==2&&trzy==3){System.out.println(" Full house"); rozdanie="<html>"+who+" Full house</html>";}
        if(cztery==4){System.out.println(" Four of a kind");  rozdanie="<html>"+who+" Four <br> of a kind</html>";}
        
        this.straight=new boolean[] {false,false,false,false,false,false};
        
        
        //sprawdz czy straigth
        for(int i=0;i<5;i++)
        {
        Card c=karty.get(i);
        if(c.wartosc.equals(Wartosc._9)){this.straight[0]=true;}
        else if(c.wartosc.equals(Wartosc._10)){this.straight[1]=true;}
        else if(c.wartosc.equals(Wartosc._J)){this.straight[2]=true;}
        else if(c.wartosc.equals(Wartosc._Q)){this.straight[3]=true;}
        else if(c.wartosc.equals(Wartosc._K)){this.straight[4]=true;}
        else if(c.wartosc.equals(Wartosc._A)){this.straight[5]=true;}
        }
        
        for(int i=0;i<6;i++)
        {
        System.out.print(" "+this.straight[i]);
        }
        //
        if(straight[0]==true&&straight[1]==true&&straight[2]==true&&straight[3]==true&&straight[4]==true)
        {
            rozdanie="<html>"+who+" Straight</html>";
            if(ilosc_wystapien_kolor.get(0)==5)
            {
            rozdanie="<html>"+who+" Poker</html>";
            }
        };
        
        if(straight[1]==true&&straight[2]==true&&straight[3]==true&&straight[4]==true&&straight[5]==true)
        {
            rozdanie="<html>"+who+" Straight</html>";
            if(ilosc_wystapien_kolor.get(0)==5)
            {
            rozdanie="<html>"+who+" Poker</html>";
            }
        };
        
        
        
        for(int i=0;i<5;i++)
        {
            if(ilosc_wystapien.get(i)==1)
            {
                ilosc_wystapien_pojedyncze.add(i);
            }
        }
        //System.out.println(ilosc_wystapien_pojedyncze);
        this.jedynki_do_wymiany=ilosc_wystapien_pojedyncze;
    }
    
    
    
}
