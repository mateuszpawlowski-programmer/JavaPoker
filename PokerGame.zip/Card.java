/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokergame;

/**
 *
 * @author M
 */
public class Card
{
    
    Enum kolor;
    
    Enum wartosc;
    
    Card(Enum k,Enum val)
    {
    this.kolor=k;
    this.wartosc=val;
    }
    
    
    //public void getCard(){System.out.print("Card: "+kolor.toString()+" "+wartosc.name());}
    public void getCard(){System.out.print("|"+kolor.toString()+" "+wartosc.name()+"| ");}
    public String toString(){return ""+kolor.toString()+" "+wartosc.name().replace('_', ' ')+" ";}

}